import streamlit as st
import requests
import datetime
import pytz
import re
import json
import streamlit.components.v1 as components

# ====== 기본 세팅 ======
st.set_page_config(page_title="🍱 상암고 급식 캘린더", layout="wide")
st.markdown("<h1 style='text-align:center; color:#2E7D32;'>🍱 상암고 급식 앱</h1>", unsafe_allow_html=True)

kst = pytz.timezone("Asia/Seoul")
오늘 = datetime.datetime.now(kst)

# ====== 데이터 불러오기 함수 ======
def get_meal_data(date):
    API_KEY = "여기에_API_KEY_입력"
    ATPT_OFCDC_SC_CODE = "B10"   # 교육청 코드
    SD_SCHUL_CODE = "7010806"    # 상암고등학교 코드
    ymd = date.strftime("%Y%m%d")
    url = f"https://open.neis.go.kr/hub/mealServiceDietInfo?KEY={API_KEY}&Type=json&pIndex=1&pSize=30&ATPT_OFCDC_SC_CODE={ATPT_OFCDC_SC_CODE}&SD_SCHUL_CODE={SD_SCHUL_CODE}&MLSV_YMD={ymd}"
    response = requests.get(url)

    try:
        data = response.json()
        meals = data['mealServiceDietInfo'][1]['row']
        result = []
        for meal in meals:
            menu = meal['DDISH_NM'].replace("<br/>", "\n")
            menu = re.sub(r"\([^)]*\)", "", menu)  # 알레르기 표시 제거
            result.append({
                "날짜": meal['MLSV_YMD'],
                "식사": meal['MMEAL_SC_NM'],
                "메뉴": menu
            })
        return result
    except Exception:
        return None

# ====== 오늘 + 이번 주 데이터 표시 ======
st.subheader("🥗 오늘의 급식")
today_meal = get_meal_data(오늘)
if today_meal:
    for meal in today_meal:
        st.success(f"🍴 {meal['식사']} - {meal['메뉴']}")
else:
    st.warning("오늘은 급식 정보가 없어요!")

st.subheader("📅 이번 주 급식 미리보기")
for i in range(7):
    day = 오늘 + datetime.timedelta(days=i)
    meals = get_meal_data(day)
    if meals:
        for idx, meal in enumerate(meals):
            safe_content = meal['메뉴'].replace("\n", "<br>")
            components.html(f"""
            <div style='background: linear-gradient(135deg, #e8f5e9, #ffffff); 
                        border-radius: 15px; 
                        padding: 15px; margin-bottom: 15px; 
                        box-shadow: 0 4px 12px rgba(0,0,0,0.1); 
                        transition: all 0.3s ease;'>
                <h4 style='color:#2E7D32; margin:0;'>{meal['날짜']} - {meal['식사']}</h4>
                <p style='color:#333; font-size:0.95rem; margin-top:8px;'>{safe_content}</p>
                <div style='margin-top: 15px; text-align: center;'>
                    <button onclick="showFullMenu{idx}()" 
                            style='background: linear-gradient(135deg, #66bb6a, #4caf50); 
                                   color: white; border: none; padding: 8px 20px; 
                                   border-radius: 20px; font-size: 0.9rem; 
                                   cursor: pointer; font-weight: 500; 
                                   box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3); 
                                   transition: all 0.3s ease;'
                            onmouseover="this.style.transform='scale(1.05)'"
                            onmouseout="this.style.transform='scale(1)'">
                        전체 보기 🍴
                    </button>
                </div>
            </div>
            <script>
            function showFullMenu{idx}() {{
                Swal.fire({{
                    title: '📅 {meal['날짜']} 급식 전체 메뉴',
                    html: `{safe_content}`,
                    confirmButtonText: '맛있겠다! 😋',
                    confirmButtonColor: '#4caf50',
                    width: 600,
                    background: '#ffffff',
                    backdrop: `
                        rgba(46, 125, 50, 0.4)
                        url("https://media.giphy.com/media/26gssIytJvy1b1THO/giphy.gif")
                        center top
                        no-repeat
                    `
                }});
            }}
            </script>
            """, height=250, unsafe_allow_html=True)
